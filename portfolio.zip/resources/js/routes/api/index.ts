import developer from './developer'
import service from './service'
const api = {
    developer: Object.assign(developer, developer),
service: Object.assign(service, service),
}

export default api