import Auth from './Auth'
import DeveloperController from './DeveloperController'
import ServiceController from './ServiceController'
import WelcomeController from './WelcomeController'
import Settings from './Settings'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
DeveloperController: Object.assign(DeveloperController, DeveloperController),
ServiceController: Object.assign(ServiceController, ServiceController),
WelcomeController: Object.assign(WelcomeController, WelcomeController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers