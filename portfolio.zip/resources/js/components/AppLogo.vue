<script setup lang="ts">
import AppLogoIcon from '@/components/AppLogoIcon.vue';
</script>

<template>

    <AppLogoIcon class="size-10 fill-current text-white dark:text-black" />
    <div class="ml-1 grid flex-1 text-left text-sm">
        <span class="mb-0.5 truncate leading-tight font-semibold">Virsato</span>
    </div>
</template>
